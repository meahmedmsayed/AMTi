# AMTi System - نظام معرض أعمال بقاعدة بيانات على GitHub

## ازاي ترفعه على GitHub Pages في 3 دقايق:

### الخطوة 1: اعمل حساب GitHub
- ادخل github.com وسجل

### الخطوة 2: اعمل Repository جديد
- دوس New Repository
- سميه: AMTi
- خليه Public
- دوس Create

### الخطوة 3: ارفع الملفات
- هتلاقي زرار Add file -> Upload files
- ارفع كل الملفات اللي في الفولدر ده (index.html + data.json)
- دوس Commit

### الخطوة 4: شغل GitHub Pages
- روح Settings -> Pages
- في Source اختار main branch
- دوس Save
- بعد دقيقة هيظهرلك لينك موقعك: https://اسمك.github.io/AMTi

مبروك! بقى عندك موقع رسمي ببلاش!

---

## ازاي تضيف قاعدة بيانات حقيقية (مجانية):

### الحل 1: JSON بسيط (اللي شغال دلوقتي)
- المشاريع بتتحفظ في data.json
- تعدل الملف من GitHub نفسه
- سهل ومش محتاج حاجة

### الحل 2: Supabase (احترافي - مجاني 100%)
1. ادخل supabase.com
2. اعمل مشروع مجاني
3. اعمل Table اسمها projects
   - columns: id, title, type, description, link, image, isReal
4. خد الـ URL والـ KEY من Settings -> API
5. حطهم في ملف supabase-setup.js
6. ارفع التعديل على GitHub

### الحل 3: Firebase (جوجل - مجاني)
1. ادخل firebase.google.com
2. اعمل مشروع
3. شغل Firestore Database
4. نفس فكرة Supabase

---

## الباسورد والارقام:
- باسورد الورشة: DEVTORKVIP
- واتساب: 01095559134
- فودافون كاش: 01097542132

## الدومين:
بعد ما يشتغل على GitHub، تقدر تربط دومين مدفوع ببلاش من Settings -> Pages -> Custom domain

لو عايزني ارفعهولك خطوة بخطوة قولي اسمك على GitHub!
