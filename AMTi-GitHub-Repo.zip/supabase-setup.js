
// قاعدة بيانات مجانية 100% - Supabase
// 1. روح supabase.com واعمل مشروع مجاني
// 2. خد الـ URL والـ KEY وحطهم هنا

const SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co';
const SUPABASE_KEY = 'YOUR_ANON_KEY';

// عشان تفعلها، شيل التعليق من السطرين دول وحطهم في index.html قبل </body>
/*
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script>
  const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
  
  // اضافة مشروع
  async function addProject(project) {
    const { data, error } = await supabase.from('projects').insert([project]);
  }
  
  // جلب المشاريع
  async function getProjects() {
    const { data } = await supabase.from('projects').select('*');
    return data;
  }
</script>
*/
